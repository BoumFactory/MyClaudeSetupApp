# Mod notif-bureau pour Claude Code

Une notification apparaît en bas à droite de l'écran quand Claude a besoin de vous et que vous êtes dans une autre fenêtre :

- **Tâche terminée** : une carte discrète, avec la durée et la première phrase de la réponse, qui s'efface après 5 secondes.
- **Claude vous pose une question** (fenêtre de choix) : les choix sont dans la notification, vous répondez sans revenir au terminal.
- **La réponse de Claude se termine par une question** : un champ de réponse dans la notification ; ce que vous tapez est envoyé comme message.

Rien ne s'affiche quand la fenêtre de Claude Code est déjà au premier plan. Plusieurs sessions ouvertes partagent la même pile de notifications, et un bouton ramène au bon terminal.

## Prérequis

- **Windows 10 ou 11** (le mod ne fonctionne pas sur macOS ni Linux).
- **Claude Code 2.1.287 ou plus récent** : vérifiez avec `claude --version`.
- Rien à installer en plus : au premier lancement, le mod compile son petit programme d'affichage avec le compilateur C# présent dans Windows (.NET Framework 4). Il écoute uniquement sur `localhost:47613`.

## Installation

1. Décompressez l'archive : vous obtenez un dossier `mods-enseignant`. Placez-le à un endroit stable, par exemple `C:\Users\<vous>\.claude\mods-enseignant` (le mod est lu depuis ce dossier : ne le déplacez plus ensuite).
2. Dans un terminal, déclarez ce dossier comme source de mods, puis installez le mod :

```
claude plugin marketplace add "C:\Users\<vous>\.claude\mods-enseignant"
claude plugin install notif-bureau@mods-enseignant
```

3. Relancez Claude Code (ou tapez `/reload-plugins` dans une session ouverte). `/plugin` doit afficher `notif-bureau` dans l'onglet Installed.

Pour voir ce que fait le mod avant de l'installer : `claude plugin validate "C:\Users\<vous>\.claude\mods-enseignant\notif-bureau"`.

## Désactiver ou retirer

- Couper le mod : `/plugin`, onglet Installed, puis désactiver `notif-bureau`.
- Le retirer : `claude plugin uninstall notif-bureau@mods-enseignant`, puis supprimer le dossier.

## Le modifier

Le code est court et commenté : `hooks/register.ts` décide quand notifier, `daemon/NotifDaemon.cs` dessine les cartes. Le plus simple est de demander à Claude Code, lancé dans le dossier du mod : « dans ce mod, affiche la notification de fin de tâche pendant 10 secondes au lieu de 5 ». Après une modification du démon, augmentez `DAEMON_VERSION` dans `register.ts` pour qu'il soit recompilé.

Mod fourni tel quel, sans garantie. Comme tout mod, il s'exécute avec vos droits : lisez-le avant de l'installer.

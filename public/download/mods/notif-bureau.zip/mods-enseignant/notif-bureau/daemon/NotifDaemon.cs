// Démon de notifications partagé par toutes les sessions Claude Code du poste.
// Compilé par le csc de .NET Framework 4 (C# 5) : pas d'interpolation, pas de ?. ni de =>.
//
//   notif-daemon.exe --ensure <indice>  : imprime en JSON la chaîne des processus parents et la
//                                         fenêtre du terminal, et démarre le démon s'il ne tourne pas.
//   notif-daemon.exe --serve            : le démon (une seule instance, http://localhost:47613/).
//
// Routes : POST /notify (JSON) -> {id, shown} ; GET /wait?id=&ms= -> verdict ou {status:"pending"} ;
//          POST /cancel?id= ; GET /ping ; POST /quit.
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using System.Windows.Threading;

static class Native
{
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] public static extern IntPtr GetAncestor(IntPtr h, uint flags);
    [DllImport("user32.dll")] public static extern IntPtr GetWindow(IntPtr h, uint cmd);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder sb, int n);
    public delegate bool EnumProc(IntPtr h, IntPtr l);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr l);
    [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool attach);
    [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
    [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
    [DllImport("kernel32.dll")] public static extern IntPtr CreateToolhelp32Snapshot(uint flags, uint pid);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] public static extern bool Process32FirstW(IntPtr snap, ref PROCESSENTRY32W e);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] public static extern bool Process32NextW(IntPtr snap, ref PROCESSENTRY32W e);
    [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr h);
    [DllImport("kernel32.dll")] public static extern bool AttachConsole(int pid);
    [DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct PROCESSENTRY32W
    {
        public uint dwSize; public uint cntUsage; public uint th32ProcessID; public IntPtr th32DefaultHeapID;
        public uint th32ModuleID; public uint cntThreads; public uint th32ParentProcessID; public int pcPriClassBase;
        public uint dwFlags; [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public string szExeFile;
    }

    public const uint GA_ROOT = 2;
    public const uint GA_ROOTOWNER = 3;
    public const uint GW_OWNER = 4;
}

static class Terminal
{
    class Proc { public uint Parent; public string Exe; }

    static Dictionary<uint, Proc> Snapshot()
    {
        var map = new Dictionary<uint, Proc>();
        IntPtr snap = Native.CreateToolhelp32Snapshot(2, 0);
        var e = new Native.PROCESSENTRY32W();
        e.dwSize = (uint)Marshal.SizeOf(typeof(Native.PROCESSENTRY32W));
        if (Native.Process32FirstW(snap, ref e))
        {
            do { map[e.th32ProcessID] = new Proc { Parent = e.th32ParentProcessID, Exe = e.szExeFile }; }
            while (Native.Process32NextW(snap, ref e));
        }
        Native.CloseHandle(snap);
        return map;
    }

    static DateTime StartOf(uint pid)
    {
        try { return Process.GetProcessById((int)pid).StartTime; }
        catch { return DateTime.MinValue; }
    }

    // Chaîne des ancêtres, coupée dès qu'un « parent » est plus jeune que son enfant (PID recyclé).
    public static List<uint> Ancestors(out Dictionary<uint, string> exes)
    {
        var map = Snapshot();
        exes = new Dictionary<uint, string>();
        var chain = new List<uint>();
        uint pid = (uint)Process.GetCurrentProcess().Id;
        DateTime childStart = DateTime.MaxValue;
        for (int i = 0; i < 16; i++)
        {
            Proc p;
            if (!map.TryGetValue(pid, out p)) break;
            uint parent = p.Parent;
            if (parent == 0 || chain.Contains(parent) || !map.ContainsKey(parent)) break;
            DateTime ps = StartOf(parent);
            if (ps != DateTime.MinValue && childStart != DateTime.MaxValue && ps > childStart) break;
            chain.Add(parent);
            exes[parent] = map[parent].Exe;
            if (ps != DateTime.MinValue) childStart = ps;
            pid = parent;
        }
        return chain;
    }

    static string TitleOf(IntPtr h)
    {
        var sb = new StringBuilder(512);
        Native.GetWindowText(h, sb, sb.Capacity);
        return sb.ToString();
    }

    public static Dictionary<string, object> Whoami(string hint)
    {
        Dictionary<uint, string> exes;
        var chain = Ancestors(out exes);
        var windows = new Dictionary<uint, List<IntPtr>>();
        Native.EnumWindows(delegate (IntPtr h, IntPtr l)
        {
            if (!Native.IsWindowVisible(h) || Native.GetWindow(h, Native.GW_OWNER) != IntPtr.Zero) return true;
            if (TitleOf(h).Length == 0) return true;
            uint pid; Native.GetWindowThreadProcessId(h, out pid);
            if (!windows.ContainsKey(pid)) windows[pid] = new List<IntPtr>();
            windows[pid].Add(h);
            return true;
        }, IntPtr.Zero);

        IntPtr hwnd = IntPtr.Zero; string app = "";
        foreach (uint pid in chain)
        {
            List<IntPtr> list;
            if (!windows.TryGetValue(pid, out list)) continue;
            hwnd = list[0];
            if (!string.IsNullOrEmpty(hint))
                foreach (IntPtr h in list)
                    if (TitleOf(h).IndexOf(hint, StringComparison.OrdinalIgnoreCase) >= 0) { hwnd = h; break; }
            app = exes[pid];
            break;
        }
        if (hwnd == IntPtr.Zero && Native.AttachConsole(-1))
        {
            IntPtr c = Native.GetConsoleWindow();
            if (c != IntPtr.Zero) { hwnd = Native.GetAncestor(c, Native.GA_ROOTOWNER); app = "console"; }
        }
        var res = new Dictionary<string, object>();
        res["pids"] = chain.Select(delegate (uint p) { return (long)p; }).ToArray();
        res["hwnd"] = hwnd.ToInt64();
        res["app"] = app.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ? app.Substring(0, app.Length - 4) : app;
        res["title"] = hwnd == IntPtr.Zero ? "" : TitleOf(hwnd);
        return res;
    }

    public static bool IsFocused(long hwnd, IList pids)
    {
        IntPtr fg = Native.GetForegroundWindow();
        if (fg == IntPtr.Zero) return false;
        if (hwnd != 0) return Native.GetAncestor(fg, Native.GA_ROOT).ToInt64() == hwnd;
        uint pid; Native.GetWindowThreadProcessId(fg, out pid);
        foreach (object p in pids) if (Convert.ToInt64(p) == pid) return true;
        return false;
    }

    public static void Focus(long hwnd)
    {
        IntPtr h = new IntPtr(hwnd);
        if (hwnd == 0 || !Native.IsWindow(h)) return;
        if (Native.IsIconic(h)) Native.ShowWindow(h, 9);
        if (Native.SetForegroundWindow(h)) return;
        uint ignored;
        uint fgThread = Native.GetWindowThreadProcessId(Native.GetForegroundWindow(), out ignored);
        uint me = Native.GetCurrentThreadId();
        Native.AttachThreadInput(me, fgThread, true);
        Native.BringWindowToTop(h);
        Native.SetForegroundWindow(h);
        Native.AttachThreadInput(me, fgThread, false);
    }
}

class Entry
{
    public string Id;
    public string Result;
    public ManualResetEvent Done = new ManualResetEvent(false);
    public Card Card;
}

class Card
{
    public Window Win;
    public Border Frame;
    public Ellipse Dot;
    public bool IsQuestion;
    public int QuestionCount;
    public bool Acknowledged;
    public Entry Entry;
    public double TargetTop = double.NaN;
}

static class Program
{
    public const int Version = 1;
    const string Prefix = "http://localhost:47613/";
    static readonly JavaScriptSerializer Json = new JavaScriptSerializer();
    static readonly Dictionary<string, Entry> Entries = new Dictionary<string, Entry>();
    static readonly List<Card> Open = new List<Card>();
    static Dispatcher Ui;
    static DateTime LastRequest = DateTime.Now;
    static int Counter;
    static bool BlinkOn;

    static SolidColorBrush B(string hex) { var b = (SolidColorBrush)new BrushConverter().ConvertFromString(hex); b.Freeze(); return b; }
    static readonly SolidColorBrush Accent = B("#D97757"), Line = B("#E5E7EB"), Ink = B("#1F2937"), Muted = B("#6B7280"),
        Chip = B("#F3F4F6"), ChipHover = B("#FCE7DE"), White = B("#FFFFFF");

    [STAThread]
    static int Main(string[] args)
    {
        string mode = args.Length > 0 ? args[0] : "";
        if (mode == "--ensure")
        {
            var who = Terminal.Whoami(args.Length > 1 ? args[1] : "");
            bool running = false;
            try { using (Mutex.OpenExisting("Local\\ClaudeNotifDaemon" + Version)) running = true; } catch { }
            if (!running)
            {
                // ShellExecute : le démon n'hérite pas des tubes de l'appelant, qui peut donc finir de lire.
                var psi = new ProcessStartInfo(Process.GetCurrentProcess().MainModule.FileName, "--serve");
                psi.UseShellExecute = true; psi.WindowStyle = ProcessWindowStyle.Hidden;
                Process.Start(psi);
            }
            who["version"] = Version;
            Console.Out.Write(Json.Serialize(who));
            Console.Out.Flush();
            return 0;
        }
        if (mode == "--serve") return Serve();
        return 1;
    }

    static int Serve()
    {
        bool createdNew;
        var mutex = new Mutex(true, "Local\\ClaudeNotifDaemon" + Version, out createdNew);
        if (!createdNew) return 0;
        var listener = new HttpListener();
        listener.Prefixes.Add(Prefix);
        try { listener.Start(); } catch { return 2; }

        var app = new Application();
        app.ShutdownMode = ShutdownMode.OnExplicitShutdown;
        Ui = app.Dispatcher;

        var loop = new Thread(delegate ()
        {
            while (listener.IsListening)
            {
                HttpListenerContext ctx;
                try { ctx = listener.GetContext(); } catch { break; }
                ThreadPool.QueueUserWorkItem(delegate (object o) { Handle((HttpListenerContext)o); }, ctx);
            }
        });
        loop.IsBackground = true;
        loop.Start();

        var blink = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(450) };
        blink.Tick += delegate { BlinkTick(); };
        blink.Start();

        // Le démon s'arrête seul après trois heures sans aucune requête ni carte ouverte.
        var idle = new DispatcherTimer { Interval = TimeSpan.FromMinutes(5) };
        idle.Tick += delegate
        {
            if (Open.Count == 0 && (DateTime.Now - LastRequest).TotalHours > 3) app.Shutdown();
        };
        idle.Start();

        app.Run();
        listener.Close();
        GC.KeepAlive(mutex);
        return 0;
    }

    static void Reply(HttpListenerContext ctx, object body)
    {
        byte[] bytes = Encoding.UTF8.GetBytes(Json.Serialize(body));
        ctx.Response.ContentType = "application/json; charset=utf-8";
        ctx.Response.ContentLength64 = bytes.Length;
        ctx.Response.OutputStream.Write(bytes, 0, bytes.Length);
        ctx.Response.Close();
    }

    static void Handle(HttpListenerContext ctx)
    {
        try
        {
            LastRequest = DateTime.Now;
            string path = ctx.Request.Url.AbsolutePath;
            string id = ctx.Request.QueryString["id"];
            if (path == "/ping") { Reply(ctx, new Dictionary<string, object> { { "ok", true }, { "version", Version } }); return; }
            if (path == "/quit")
            {
                Reply(ctx, new Dictionary<string, object> { { "ok", true } });
                Ui.BeginInvoke(new Action(delegate { Application.Current.Shutdown(); }));
                return;
            }
            if (path == "/notify")
            {
                string body;
                using (var r = new StreamReader(ctx.Request.InputStream, Encoding.UTF8)) body = r.ReadToEnd();
                var p = Json.Deserialize<Dictionary<string, object>>(body);
                var win = Dict(p, "window");
                long hwnd = win == null ? 0 : Convert.ToInt64(Get(win, "hwnd", 0));
                IList pids = win == null ? new ArrayList() : (Get(win, "pids", new ArrayList()) as IList);
                if (Convert.ToBoolean(Get(p, "onlyIfUnfocused", false)) && Terminal.IsFocused(hwnd, pids))
                {
                    Reply(ctx, new Dictionary<string, object> { { "shown", false } });
                    return;
                }
                var entry = new Entry { Id = (Interlocked.Increment(ref Counter)).ToString() + "-" + Environment.TickCount };
                lock (Entries) Entries[entry.Id] = entry;
                Ui.BeginInvoke(new Action(delegate { ShowCard(entry, p, hwnd); }));
                Reply(ctx, new Dictionary<string, object> { { "shown", true }, { "id", entry.Id } });
                return;
            }
            Entry e = null;
            if (id != null) lock (Entries) Entries.TryGetValue(id, out e);
            if (path == "/wait")
            {
                if (e == null) { Reply(ctx, new Dictionary<string, object> { { "action", "dismiss" } }); return; }
                int ms = 20000;
                int.TryParse(ctx.Request.QueryString["ms"], out ms);
                if (e.Done.WaitOne(Math.Max(100, Math.Min(ms, 60000))))
                {
                    lock (Entries) Entries.Remove(e.Id);
                    byte[] bytes = Encoding.UTF8.GetBytes(e.Result);
                    ctx.Response.ContentType = "application/json; charset=utf-8";
                    ctx.Response.OutputStream.Write(bytes, 0, bytes.Length);
                    ctx.Response.Close();
                }
                else Reply(ctx, new Dictionary<string, object> { { "status", "pending" } });
                return;
            }
            if (path == "/cancel")
            {
                if (e != null) Ui.BeginInvoke(new Action(delegate { Finish(e, new Dictionary<string, object> { { "action", "cancelled" } }); }));
                Reply(ctx, new Dictionary<string, object> { { "ok", true } });
                return;
            }
            ctx.Response.StatusCode = 404;
            ctx.Response.Close();
        }
        catch
        {
            try { ctx.Response.StatusCode = 500; ctx.Response.Close(); } catch { }
        }
    }

    static object Get(Dictionary<string, object> d, string k, object fallback)
    {
        object v;
        return d != null && d.TryGetValue(k, out v) && v != null ? v : fallback;
    }
    static string Str(Dictionary<string, object> d, string k) { return Convert.ToString(Get(d, k, "")); }
    static Dictionary<string, object> Dict(Dictionary<string, object> d, string k) { return Get(d, k, null) as Dictionary<string, object>; }

    // --- Verdict : écrit le résultat, ferme la carte, remet la pile en ordre ---
    static void Finish(Entry e, Dictionary<string, object> result)
    {
        if (e.Result != null) return;
        e.Result = Json.Serialize(result);
        e.Done.Set();
        var c = e.Card;
        if (c != null)
        {
            Open.Remove(c);
            c.Win.Close();
            Layout();
        }
    }

    static void Layout()
    {
        Rect wa = SystemParameters.WorkArea;
        double bottom = wa.Bottom;
        for (int i = Open.Count - 1; i >= 0; i--)
        {
            var c = Open[i];
            double h = c.Win.ActualHeight > 0 ? c.Win.ActualHeight : 160;
            double top = bottom - h;
            c.Win.Left = wa.Right - c.Win.Width;
            c.Win.Visibility = top < wa.Top ? Visibility.Hidden : Visibility.Visible;
            if (double.IsNaN(c.TargetTop)) c.Win.Top = top;
            else if (Math.Abs(c.TargetTop - top) > 0.5)
            {
                var a = new DoubleAnimation(top, TimeSpan.FromMilliseconds(180));
                a.EasingFunction = new QuadraticEase();
                c.Win.BeginAnimation(Window.TopProperty, a);
            }
            c.TargetTop = top;
            bottom = top + 4;
        }
    }

    // Clignotement : une carte à plusieurs questions, ou plusieurs cartes de questions ouvertes.
    static void BlinkTick()
    {
        BlinkOn = !BlinkOn;
        int questionCards = Open.Count(delegate (Card c) { return c.IsQuestion; });
        foreach (var c in Open)
        {
            if (!c.IsQuestion) continue;
            bool blinks = !c.Acknowledged && (c.QuestionCount > 1 || questionCards > 1);
            c.Frame.BorderBrush = blinks && !BlinkOn ? Line : Accent;
            c.Dot.Opacity = blinks && !BlinkOn ? 0.25 : 1;
        }
    }

    static TextBlock Text(string s, Brush brush, double size, FontWeight weight)
    {
        return new TextBlock { Text = s, TextWrapping = TextWrapping.Wrap, Foreground = brush, FontSize = size, FontWeight = weight };
    }

    static Border Pill(string label, Brush bg, Brush fg, string tip)
    {
        var b = new Border
        {
            CornerRadius = new CornerRadius(14), Background = bg, Padding = new Thickness(11, 5, 11, 5),
            Margin = new Thickness(0, 0, 6, 6), Cursor = Cursors.Hand,
            Child = Text(label, fg, 12.5, FontWeights.Normal)
        };
        if (!string.IsNullOrEmpty(tip)) b.ToolTip = tip;
        return b;
    }

    static void ShowCard(Entry entry, Dictionary<string, object> p, long hwnd)
    {
        string mode = Str(p, "mode");
        var labels = Dict(p, "labels") ?? new Dictionary<string, object>();
        var card = new Card { Entry = entry, IsQuestion = mode != "info" };
        entry.Card = card;

        var w = new Window
        {
            WindowStyle = WindowStyle.None, AllowsTransparency = true, Background = Brushes.Transparent,
            Topmost = true, ShowInTaskbar = false, ShowActivated = false, ResizeMode = ResizeMode.NoResize,
            SizeToContent = SizeToContent.Height, Width = 400, FontFamily = new FontFamily("Segoe UI"), FontSize = 13,
            Opacity = 0, Left = SystemParameters.WorkArea.Right - 400, Top = SystemParameters.WorkArea.Bottom - 10
        };
        card.Win = w;
        var frame = new Border
        {
            CornerRadius = new CornerRadius(12), BorderThickness = new Thickness(2), BorderBrush = card.IsQuestion ? Accent : Line,
            Background = White, Padding = new Thickness(14, 12, 14, 12), Margin = new Thickness(12, 6, 12, 6),
            Effect = new DropShadowEffect { BlurRadius = 18, ShadowDepth = 3, Opacity = 0.25 }
        };
        card.Frame = frame;
        w.Content = frame;
        var stack = new StackPanel();
        frame.Child = stack;
        frame.MouseEnter += delegate { card.Acknowledged = true; };

        // En-tête
        var head = new DockPanel { Margin = new Thickness(0, 0, 0, 2) };
        var dot = new Ellipse { Width = 10, Height = 10, Fill = Accent, Margin = new Thickness(0, 0, 8, 0), VerticalAlignment = VerticalAlignment.Center };
        card.Dot = dot;
        DockPanel.SetDock(dot, Dock.Left);
        var close = Text("✕", Muted, 13, FontWeights.Normal);
        close.Cursor = Cursors.Hand; close.VerticalAlignment = VerticalAlignment.Center; close.ToolTip = Str(labels, "close");
        DockPanel.SetDock(close, Dock.Right);
        close.MouseLeftButtonUp += delegate { Finish(entry, new Dictionary<string, object> { { "action", "dismiss" } }); };
        var title = Text(Str(p, "title"), Ink, 13.5, FontWeights.SemiBold);
        title.VerticalAlignment = VerticalAlignment.Center;
        head.Children.Add(dot); head.Children.Add(close); head.Children.Add(title);
        stack.Children.Add(head);

        string source = Str(p, "source");
        if (source.Length > 0)
        {
            var src = Text(source, Muted, 11.5, FontWeights.Normal);
            src.Margin = new Thickness(18, 0, 0, 6);
            stack.Children.Add(src);
        }
        string message = Str(p, "message");
        if (message.Length > 0)
        {
            var m = Text(message, Ink, 13, FontWeights.Normal);
            m.Margin = new Thickness(0, 2, 0, 8);
            stack.Children.Add(m);
        }

        // Questions à choix
        var selections = new Dictionary<int, List<string>>();
        var pills = new List<KeyValuePair<Border, KeyValuePair<int, string>>>();
        TextBox input = null;
        Border send = null;
        IList questions = Get(p, "questions", new ArrayList()) as IList;
        card.QuestionCount = mode == "ask" ? questions.Count : (int)Convert.ToInt32(Get(p, "questionCount", 1));

        Action refresh = null;
        Action submit = delegate
        {
            string text = input == null ? "" : input.Text.Trim();
            if (mode == "reply")
            {
                if (text.Length == 0) return;
                Finish(entry, new Dictionary<string, object> { { "action", "reply" }, { "text", text } });
                return;
            }
            if (send == null || !(bool)send.Tag) return;
            var answers = new Dictionary<string, object>();
            foreach (var kv in selections) if (kv.Value.Count > 0) answers[kv.Key.ToString()] = kv.Value.ToArray();
            Finish(entry, new Dictionary<string, object> { { "action", "answer" }, { "answers", answers }, { "text", text } });
        };
        refresh = delegate
        {
            foreach (var pr in pills)
            {
                List<string> sel;
                bool on = selections.TryGetValue(pr.Value.Key, out sel) && sel.Contains(pr.Value.Value);
                pr.Key.Background = on ? Accent : (pr.Key.IsMouseOver ? ChipHover : Chip);
                ((TextBlock)pr.Key.Child).Foreground = on ? White : Ink;
            }
            if (send != null)
            {
                bool ok = input != null && input.Text.Trim().Length > 0;
                if (mode == "ask")
                {
                    bool all = true;
                    for (int i = 0; i < questions.Count; i++)
                    {
                        List<string> sel;
                        if (!selections.TryGetValue(i, out sel) || sel.Count == 0) all = false;
                    }
                    ok = ok || all;
                }
                send.Opacity = ok ? 1 : 0.4;
                send.Tag = ok;
            }
        };

        if (mode == "ask")
        {
            bool single = questions.Count == 1 && !Convert.ToBoolean(Get(questions[0] as Dictionary<string, object>, "multiSelect", false));
            for (int i = 0; i < questions.Count; i++)
            {
                var q = questions[i] as Dictionary<string, object>;
                int qi = i;
                bool multi = Convert.ToBoolean(Get(q, "multiSelect", false));
                string label = questions.Count > 1 ? (i + 1) + ". " + Str(q, "question") : Str(q, "question");
                var qt = Text(label, Ink, 13, FontWeights.SemiBold);
                qt.Margin = new Thickness(0, 4, 0, 4);
                stack.Children.Add(qt);
                var wrap = new WrapPanel();
                foreach (object oo in (Get(q, "options", new ArrayList()) as IList))
                {
                    var o = oo as Dictionary<string, object>;
                    string optLabel = Str(o, "label");
                    var pill = Pill(optLabel, Chip, Ink, Str(o, "description"));
                    pills.Add(new KeyValuePair<Border, KeyValuePair<int, string>>(pill, new KeyValuePair<int, string>(qi, optLabel)));
                    pill.MouseEnter += delegate { refresh(); };
                    pill.MouseLeave += delegate { refresh(); };
                    pill.MouseLeftButtonUp += delegate
                    {
                        List<string> cur;
                        if (!selections.TryGetValue(qi, out cur)) { cur = new List<string>(); selections[qi] = cur; }
                        if (single) { cur.Clear(); cur.Add(optLabel); refresh(); submit(); return; }
                        if (multi) { if (cur.Contains(optLabel)) cur.Remove(optLabel); else cur.Add(optLabel); }
                        else { cur.Clear(); cur.Add(optLabel); }
                        refresh();
                    };
                    wrap.Children.Add(pill);
                }
                stack.Children.Add(wrap);
            }
        }

        if (mode == "ask" || mode == "reply")
        {
            var row = new DockPanel { Margin = new Thickness(0, 6, 0, 0) };
            send = new Border
            {
                CornerRadius = new CornerRadius(16), Background = Accent, Width = 32, Height = 32,
                Margin = new Thickness(6, 0, 0, 0), Cursor = Cursors.Hand, ToolTip = Str(labels, "send"), Tag = false
            };
            var arrow = Text("➤", White, 14, FontWeights.Normal);
            arrow.HorizontalAlignment = HorizontalAlignment.Center; arrow.VerticalAlignment = VerticalAlignment.Center;
            send.Child = arrow;
            send.MouseLeftButtonUp += delegate { submit(); };
            DockPanel.SetDock(send, Dock.Right);
            var grid = new Grid();
            input = new TextBox
            {
                Padding = new Thickness(8, 6, 8, 6), BorderBrush = Line, TextWrapping = TextWrapping.Wrap,
                MaxHeight = 120, VerticalScrollBarVisibility = ScrollBarVisibility.Auto
            };
            var hint = Text(Str(labels, mode == "ask" ? "other" : "reply"), Muted, 13, FontWeights.Normal);
            hint.Margin = new Thickness(11, 7, 0, 0); hint.IsHitTestVisible = false;
            input.TextChanged += delegate { hint.Visibility = input.Text.Length > 0 ? Visibility.Collapsed : Visibility.Visible; refresh(); };
            input.PreviewKeyDown += delegate (object s, KeyEventArgs ev)
            {
                if (ev.Key == Key.Enter && (Keyboard.Modifiers & ModifierKeys.Shift) == 0) { ev.Handled = true; submit(); }
                if (ev.Key == Key.Escape) Finish(entry, new Dictionary<string, object> { { "action", "dismiss" } });
            };
            grid.Children.Add(input); grid.Children.Add(hint);
            row.Children.Add(send); row.Children.Add(grid);
            stack.Children.Add(row);
        }

        // Pied : ramener le terminal au premier plan
        string focusLabel = Str(labels, mode == "info" ? "focus" : "terminal");
        if (focusLabel.Length > 0 && (hwnd != 0 || mode != "info"))
        {
            var link = Text(focusLabel, Muted, 11.5, FontWeights.Normal);
            link.Margin = new Thickness(0, 8, 0, 0);
            link.HorizontalAlignment = HorizontalAlignment.Right;
            link.TextDecorations = TextDecorations.Underline;
            link.Cursor = Cursors.Hand;
            link.MouseLeftButtonUp += delegate (object s, MouseButtonEventArgs ev)
            {
                ev.Handled = true;
                Terminal.Focus(hwnd);
                Finish(entry, new Dictionary<string, object> { { "action", "terminal" } });
            };
            stack.Children.Add(link);
        }

        // Info : disparaît seule, pause au survol, un clic ramène au terminal
        if (mode == "info")
        {
            frame.Cursor = Cursors.Hand;
            frame.MouseLeftButtonUp += delegate
            {
                Terminal.Focus(hwnd);
                Finish(entry, new Dictionary<string, object> { { "action", "terminal" } });
            };
            var timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(Convert.ToInt32(Get(p, "timeoutMs", 3000))) };
            timer.Tick += delegate
            {
                timer.Stop();
                var fade = new DoubleAnimation(0, TimeSpan.FromMilliseconds(400));
                fade.Completed += delegate { if (!frame.IsMouseOver) Finish(entry, new Dictionary<string, object> { { "action", "timeout" } }); };
                w.BeginAnimation(UIElement.OpacityProperty, fade);
            };
            frame.MouseEnter += delegate { timer.Stop(); w.BeginAnimation(UIElement.OpacityProperty, null); w.Opacity = 1; };
            frame.MouseLeave += delegate { timer.Start(); };
            w.ContentRendered += delegate { timer.Start(); };
        }

        w.SizeChanged += delegate { Layout(); };
        w.ContentRendered += delegate { w.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(1, TimeSpan.FromMilliseconds(160))); };
        Open.Add(card);
        if (refresh != null) refresh();
        w.Show();
        Layout();
        if (Convert.ToBoolean(Get(p, "sound", false))) System.Media.SystemSounds.Asterisk.Play();
    }
}

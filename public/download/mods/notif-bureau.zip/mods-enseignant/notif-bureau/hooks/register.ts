import type { EngineInterface, Register } from 'claude-code'

// Notifications de bureau (bas droite) pour l'agent principal seulement, et seulement quand
// la fenêtre de son terminal n'a pas le focus :
// - AskUserQuestion : les choix dans la notif, réponse renvoyée directement à l'outil ;
// - fin de tour qui se termine par une question : champ de réponse, envoyé comme prompt ;
// - fin de tour ordinaire : info « tâche terminée » qui s'efface après INFO_MS.
// L'affichage est confié à un démon unique (daemon/NotifDaemon.cs) partagé par toutes les
// sessions : il empile les cartes, fait clignoter quand les questions s'accumulent et ramène
// le bon terminal au premier plan.

const INFO_MS = 5000
const DAEMON_VERSION = 1
const DAEMON_URL = 'http://localhost:47613'
const FRAMEWORK = 'C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319'

const LABELS = {
  close: 'Fermer',
  send: 'Envoyer (Entrée)',
  other: 'Autre réponse…',
  reply: 'Ta réponse…',
  terminal: 'Répondre dans le terminal',
  focus: 'Aller au terminal',
}

type Question = { question: string; multiSelect: boolean; options: { label: string; description?: string }[] }

type Payload =
  | { mode: 'info'; title: string; message: string; timeoutMs: number }
  | { mode: 'ask'; title: string; questions: Question[]; sound: boolean }
  | { mode: 'reply'; title: string; message: string; questionCount: number; sound: boolean }

type Outcome =
  | { action: 'dismiss' | 'terminal' | 'timeout' | 'cancelled' }
  | { action: 'answer'; answers?: Record<string, string[]>; text?: string }
  | { action: 'reply'; text: string }

type Whoami = { pids: number[]; hwnd: number; app: string; title: string }

type Popup = { outcome: Promise<Outcome | null>; close: () => void }

let me: Whoami | undefined
let project = ''
let seq = 0

function cleanMarkdown(text: string): string {
  return text.replace(/[*_`#>]/g, '').replace(/\[([^\]]*)\]\([^)]*\)/g, '$1').trim()
}

function excerpt(text: string, max: number): string {
  const flat = text.replace(/\s+/g, ' ').trim()
  return flat.length > max ? `${flat.slice(0, max - 1)}…` : flat
}

function winPath(path: string): string {
  return path.replace(/\//g, '\\')
}

// Compile le démon si besoin, arrête une ancienne version, démarre le démon et
// mémorise la fenêtre du terminal de cette session.
async function ensureDaemon($: EngineInterface): Promise<void> {
  const root = winPath($.plugin.root)
  const exe = `${root}\\runtime\\notif-daemon-v${DAEMON_VERSION}.exe`
  if (!(await $.fs.exists(exe))) {
    const built = await $.process.run(
      [
        `${FRAMEWORK}\\csc.exe`, '-nologo', '-target:winexe', '-codepage:65001', '-optimize', `-out:${exe}`,
        `-r:${FRAMEWORK}\\WPF\\PresentationFramework.dll`, `-r:${FRAMEWORK}\\WPF\\PresentationCore.dll`,
        `-r:${FRAMEWORK}\\WPF\\WindowsBase.dll`, `-r:${FRAMEWORK}\\System.Xaml.dll`,
        `-r:${FRAMEWORK}\\System.Web.Extensions.dll`, `${root}\\daemon\\NotifDaemon.cs`,
      ],
      { timeoutMs: 60000 },
    )
    if (built.exitCode !== 0) throw new Error(`notif-bureau : compilation du démon impossible\n${built.stdout}`)
  }
  const ping = await $.http.fetch(`${DAEMON_URL}/ping`).catch(() => undefined)
  if (ping?.ok) {
    const { version } = JSON.parse(ping.text) as { version: number }
    if (version !== DAEMON_VERSION) {
      await $.http.fetch(`${DAEMON_URL}/quit`, { method: 'POST', body: '' }).catch(() => undefined)
      await $.clock.sleep(600)
    }
  }
  const who = await $.process.run([exe, '--ensure', project], { timeoutMs: 15000 })
  me = JSON.parse(who.stdout) as Whoami
  await $.clock.sleep(300)
}

async function post($: EngineInterface, body: string): Promise<{ shown: boolean; id?: string }> {
  const send = () =>
    $.http.fetch(`${DAEMON_URL}/notify`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body })
  let res = await send().catch(() => undefined)
  if (!res?.ok) {
    await ensureDaemon($)
    res = await send()
  }
  return JSON.parse(res.text) as { shown: boolean; id?: string }
}

function open($: EngineInterface, payload: Payload): Popup {
  const holder = { id: undefined as string | undefined, closed: false }
  const outcome = runPopup($, payload, holder)
  return {
    outcome,
    close: () => {
      holder.closed = true
      if (holder.id) void $.http.fetch(`${DAEMON_URL}/cancel?id=${holder.id}`, { method: 'POST', body: '' }).catch(() => undefined)
    },
  }
}

// Envoie la carte au démon et attend son verdict par attentes successives ; null : rien n'a été
// affiché (le terminal avait le focus).
async function runPopup(
  $: EngineInterface,
  payload: Payload,
  holder: { id: string | undefined; closed: boolean },
): Promise<Outcome | null> {
  if (!me) await ensureDaemon($)
  const source = [project, me?.app].filter(Boolean).join(' · ')
  const body = JSON.stringify({
    ...payload,
    source,
    labels: LABELS,
    onlyIfUnfocused: true,
    window: { hwnd: me?.hwnd ?? 0, pids: me?.pids ?? [] },
    seq: ++seq,
  })
  const { shown, id } = await post($, body)
  if (!shown || !id) return null
  holder.id = id
  if (holder.closed) {
    void $.http.fetch(`${DAEMON_URL}/cancel?id=${id}`, { method: 'POST', body: '' }).catch(() => undefined)
    return { action: 'cancelled' }
  }
  for (;;) {
    const res = await $.http.fetch(`${DAEMON_URL}/wait?id=${id}&ms=20000`)
    const out = JSON.parse(res.text) as Outcome | { status: 'pending' }
    if (!('status' in out)) return out
  }
}

export const register: Register = on => {
  let replyPopup: Popup | undefined

  on('session.start', async ($, e, next) => {
    const started = await next(e)
    project = e.cwd.replace(/[\\/]+$/, '').split(/[\\/]/).pop() ?? ''
    void ensureDaemon($).catch(err => $.ui.log(String(err), { to: 'debug' }))
    return started
  })

  on('tool.call', { tool: 'AskUserQuestion' }, async ($, e, next) => {
    if (e.agentId !== undefined) return next(e)

    const questions = e.questions
    const title =
      questions.length > 1
        ? `Claude a ${questions.length} questions pour toi`
        : `Claude a besoin de toi · ${questions[0]?.header ?? ''}`
    const popup = open($, {
      mode: 'ask',
      title,
      questions: questions.map(q => ({
        question: q.question,
        multiSelect: q.multiSelect,
        options: q.options.map(o => ({ label: o.label, description: o.description })),
      })),
      sound: true,
    })
    next.signal.addEventListener('abort', popup.close)
    const out = await popup.outcome
    if (!out || out.action !== 'answer') return next(e)

    const answers: Record<string, string> = {}
    questions.forEach((q, i) => {
      const picked = out.answers?.[String(i)]
      if (picked && picked.length > 0) answers[q.question] = picked.join(', ')
    })
    const text = out.text?.trim() ?? ''
    const only = questions.length === 1 ? questions[0] : undefined
    let response: string | undefined
    if (text) {
      if (only && answers[only.question] === undefined) answers[only.question] = text
      else response = text
    }

    return { result: { questions, answers, ...(response ? { response } : {}) } }
  }).catch(($, e, next) => next(e))

  on('prompt.submit', ($, e, next) => {
    // La personne a répondu dans le terminal : la notif de réponse n'a plus lieu d'être.
    if (e.origin?.kind !== 'plugin') {
      replyPopup?.close()
      replyPopup = undefined
    }
    return next(e)
  }).catch(($, e, next) => next(e))

  on('turn.complete', async ($, e, next) => {
    const done = await next(e)
    if (e.agentId !== undefined || e.isAborted || e.reason !== 'answer') return done

    const paragraphs = e.answer.trim().split(/\n\s*\n/).map(cleanMarkdown).filter(Boolean)
    const last = paragraphs[paragraphs.length - 1] ?? ''
    const isQuestion = /\?[\s)»"'.!]*$/.test(last)

    if (!isQuestion) {
      const minutes = Math.floor(e.durationMs / 60000)
      const seconds = Math.round((e.durationMs % 60000) / 1000)
      const duration = minutes > 0 ? `${minutes} min ${seconds} s` : `${seconds} s`
      void open($, {
        mode: 'info',
        title: `Tâche terminée · ${duration}`,
        message: excerpt(paragraphs[0] ?? 'Claude a fini.', 160),
        timeoutMs: INFO_MS,
      }).outcome.catch(() => undefined)
      return done
    }

    const asked = (paragraphs.slice(-3).join('\n').match(/\?/g) ?? []).length
    replyPopup?.close()
    const popup = open($, {
      mode: 'reply',
      title: asked > 1 ? `Claude a ${asked} questions pour toi` : 'Claude attend ta réponse',
      message: excerpt(asked > 1 ? paragraphs.slice(-3).join(' ') : last, 420),
      questionCount: asked,
      sound: true,
    })
    replyPopup = popup
    void popup.outcome
      .then(out => {
        if (replyPopup === popup) replyPopup = undefined
        if (out?.action === 'reply' && out.text.trim()) return $.prompt.submit({ text: out.text.trim() })
      })
      .catch(() => undefined)
    return done
  })
}
